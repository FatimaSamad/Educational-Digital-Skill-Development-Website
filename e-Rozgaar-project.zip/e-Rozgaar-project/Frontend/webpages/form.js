document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("signupForm");

    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent form submission to handle validation

        // Clear previous errors
        clearErrors();

        let isValid = true;

        // Validate username
        const username = document.getElementById("username").value;
        if (!username || username.length < 6) {
            showError("username", "Username must be at least 6 characters long");
            isValid = false;
        }

        // Validate email
        const email = document.getElementById("email").value;
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email || !emailPattern.test(email)) {
            showError("email", "Please enter a valid email address");
            isValid = false;
        }

        // Validate password
        const password = document.getElementById("password").value;
        if (!password || password.length < 6) {
            showError("password", "Password must be at least 6 characters long");
            isValid = false;
        }

        // Validate confirm password
        const confirmPassword = document.getElementById("confirm_password").value;
        if (confirmPassword !== password) {
            showError("confirm_password", "Passwords do not match");
            isValid = false;
        }

        if (isValid) {
            alert("Form successfully submitted!");
            form.submit();
        }
    });

    function showError(fieldId, message) {
        const errorElement = document.getElementById(`${fieldId}Error`);
        errorElement.textContent = message;
        document.getElementById(fieldId).classList.add("error");
    }

    function clearErrors() {
        const errors = document.querySelectorAll(".error");
        errors.forEach(error => {
            error.textContent = "";
        });

        const inputs = document.querySelectorAll("input");
        inputs.forEach(input => {
            input.classList.remove("error");
        });
    }
});
