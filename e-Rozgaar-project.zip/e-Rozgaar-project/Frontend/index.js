// FAQs 
// Script to handle the accordion functionality
document.querySelectorAll('.accordion').forEach(button => {
    button.addEventListener('click', () => {
        const panel = button.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
});

// Gallery
document.addEventListener('DOMContentLoaded', function() {
    var lightbox = document.getElementById('lightbox');
    var lightboxImage = document.getElementById('lightboxImage');
    var caption = document.getElementById('caption');
    var close = document.getElementById('close');

    // Event delegation to handle gallery item clicks
    document.querySelectorAll('.gallery-image').forEach(function(image) {
        image.addEventListener('click', function() {
            lightbox.style.display = 'block';
            lightboxImage.src = this.src.replace('thumbnail', 'large'); // Assuming large images are named similarly
            caption.textContent = this.alt;
        });
    });

    // Close lightbox when clicking the close button
    close.addEventListener('click', function() {
        lightbox.style.display = 'none';
    });

    // Close lightbox when clicking outside of the image
    lightbox.addEventListener('click', function(event) {
        if (event.target === lightbox) {
            lightbox.style.display = 'none';
        }
    });
});


//    form validation
$(document).ready(function () {
    $('#loginForm').on('submit', function (event) {
        // Prevent form from submitting
        event.preventDefault();

        // Regular expressions for validation
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const passwordPattern = /^.{6,}$/; // At least 6 characters
        // Get input values
        const email = $('#email').val();
        const password = $('#password').val();

        // Initialize error flags
        let isValid = true;

        // Validate email
        if (!emailPattern.test(email)) {
            $('#emailError').show();
            isValid = false;
        } else {
            $('#emailError').hide();
        }

        // Validate password
        if (!passwordPattern.test(password)) {
            $('#passwordError').show();
            isValid = false;
        } else {
            $('#passwordError').hide();
        }

        // If valid, you can handle the form submission
        if (isValid) {
            alert('Login successful!');
            this.submit();
        }
    });
});

// login form
$(document).ready(function() {
    $('#loginform').on('submit', function(event) {
        // Prevent the default form submission
        event.preventDefault();

        // Clear previous errors
        $('.error').hide();

        // Initialize validation flag
        let isValid = true;

        // Validate email
        const email = $('#email').val();
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            $('#emailError').show();
            isValid = false;
        }

        // Validate password
        const password = $('#password').val();
        if (password.length < 6) {
            $('#passwordError').show();
            isValid = false;
        }

        // If form is valid,  submit it or handle it as needed
        if (isValid) {
            alert('Form is valid and ready for submission.');
        }
    });
});
// team Section
$(document).ready(function () {
    $('.team-carousel').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
});

// Courses Section
$(document).ready(function(){
    $('.course-slider').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,         // Enable automatic sliding
        autoplaySpeed: 3000,    // Set the speed for sliding (3 seconds)
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
});
// contact
// Function to handle form submission and validation
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission to handle it manually
    // Clear previous error messages and success message
    document.getElementById('fullNameError').textContent = '';
    document.getElementById('emailError').textContent = '';
    document.getElementById('messageError').textContent = '';
    document.getElementById('successMessage').textContent = '';

    let valid = true;

    // Validate Full Name
    const fullName = document.getElementById('fullName').value.trim();
    if (fullName === '') {
        document.getElementById('fullNameError').textContent = 'Full Name is required.';
        valid = false;
    } else if (fullName.length < 2) {
        document.getElementById('fullNameError').textContent = 'Full Name must be at least 2 characters long.';
        valid = false;
    }

    // Validate Email
    const email = document.getElementById('email').value.trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === '') {
        document.getElementById('emailError').textContent = 'Email is required.';
        valid = false;
    } else if (!emailPattern.test(email)) {
        document.getElementById('emailError').textContent = 'Please enter a valid email address.';
        valid = false;
    }

    // Validate Message
    const message = document.getElementById('message').value.trim();
    if (message === '') {
        document.getElementById('messageError').textContent = 'Message is required.';
        valid = false;
    } else if (message.length < 10) {
        document.getElementById('messageError').textContent = 'Message must be at least 10 characters long.';
        valid = false;
    }

    // If form is valid, display success message
    if (valid) {
        document.getElementById('successMessage').textContent = 'Your message has been sent successfully!';
    }
});
// Enhanced form validation with better UX
class FormValidator {
  constructor(formId) {
    this.form = document.getElementById(formId);
    this.fields = this.form.querySelectorAll('input, textarea, select');
    this.init();
  }
  
  init() {
    this.form.addEventListener('submit', this.handleSubmit.bind(this));
    
    // Real-time validation
    this.fields.forEach(field => {
      field.addEventListener('blur', this.validateField.bind(this));
      field.addEventListener('input', this.clearError.bind(this));
    });
  }
  
  validateField(e) {
    const field = e.target;
    const value = field.value.trim();
    const fieldName = field.name;
    
    this.clearError(field);
    
    switch(fieldName) {
      case 'fullName':
        if (value.length < 2) {
          this.showError(field, 'Name must be at least 2 characters long');
          return false;
        }
        break;
        
      case 'email':
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(value)) {
          this.showError(field, 'Please enter a valid email address');
          return false;
        }
        break;
        
      case 'message':
        if (value.length < 10) {
          this.showError(field, 'Message must be at least 10 characters long');
          return false;
        }
        break;
    }
    
    return true;
  }
  
  showError(field, message) {
    field.classList.add('error');
    const errorElement = field.parentNode.querySelector('.error-message');
    if (errorElement) {
      errorElement.textContent = message;
    }
  }
  
  clearError(e) {
    const field = e.target || e;
    field.classList.remove('error');
    const errorElement = field.parentNode.querySelector('.error-message');
    if (errorElement) {
      errorElement.textContent = '';
    }
  }
  
  handleSubmit(e) {
    e.preventDefault();
    
    let isValid = true;
    
    this.fields.forEach(field => {
      if (!this.validateField({ target: field })) {
        isValid = false;
      }
    });
    
    if (isValid) {
      this.submitForm();
    }
  }
  
  submitForm() {
    // Add form submission logic here
    const successMessage = this.form.querySelector('.success-message');
    successMessage.textContent = 'Your message has been sent successfully!';
    successMessage.style.display = 'block';
    
    // Reset form after 3 seconds
    setTimeout(() => {
      this.form.reset();
      successMessage.style.display = 'none';
    }, 3000);
  }
}

// Initialize form validators
document.addEventListener('DOMContentLoaded', function() {
  new FormValidator('contactForm');
  new FormValidator('loginForm');
});
// ==================== PHP BACKEND INTEGRATION ====================
// Add this section to your existing index.js file

const API_BASE_URL = 'http://localhost/e-rozgaar-project/backend/api';

// API Service Classes
class AuthService {
    static async register(userData) {
        try {
            const response = await fetch(`${API_BASE_URL}/auth.php?action=register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData),
            });
            return await response.json();
        } catch (error) {
            console.error('Registration error:', error);
            return { success: false, message: 'Network error occurred' };
        }
    }

    static async login(credentials) {
        try {
            const response = await fetch(`${API_BASE_URL}/auth.php?action=login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(credentials),
            });
            return await response.json();
        } catch (error) {
            console.error('Login error:', error);
            return { success: false, message: 'Network error occurred' };
        }
    }
}

class CourseService {
    static async getAllCourses() {
        try {
            const response = await fetch(`${API_BASE_URL}/courses.php`);
            return await response.json();
        } catch (error) {
            console.error('Courses fetch error:', error);
            return { success: false, message: 'Failed to load courses' };
        }
    }

    static async enrollCourse(courseId, token) {
        try {
            const response = await fetch(`${API_BASE_URL}/courses.php?action=enroll`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
                body: JSON.stringify({ course_id: courseId }),
            });
            return await response.json();
        } catch (error) {
            console.error('Enrollment error:', error);
            return { success: false, message: 'Enrollment failed' };
        }
    }
}

class ContactService {
    static async sendMessage(contactData) {
        try {
            const response = await fetch(`${API_BASE_URL}/contact.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(contactData),
            });
            return await response.json();
        } catch (error) {
            console.error('Contact form error:', error);
            return { success: false, message: 'Failed to send message' };
        }
    }
}

// Utility Functions
class StorageService {
    static setToken(token) {
        localStorage.setItem('auth_token', token);
    }

    static getToken() {
        return localStorage.getItem('auth_token');
    }

    static removeToken() {
        localStorage.removeItem('auth_token');
    }

    static setUser(user) {
        localStorage.setItem('user_data', JSON.stringify(user));
    }

    static getUser() {
        const user = localStorage.getItem('user_data');
        return user ? JSON.parse(user) : null;
    }
}

// Enhanced Form Handlers - UPDATE YOUR EXISTING ONES
document.addEventListener('DOMContentLoaded', function() {
    // Enhanced Login Form Handler
    const loginForm = document.getElementById('loginForm') || document.getElementById('loginform');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            // Clear previous errors
            document.querySelectorAll('.error').forEach(error => error.style.display = 'none');

            let isValid = true;

            // Email validation
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                document.getElementById('emailError').style.display = 'block';
                isValid = false;
            }

            // Password validation
            if (password.length < 6) {
                document.getElementById('passwordError').style.display = 'block';
                isValid = false;
            }

            if (isValid) {
                // Show loading state
                const submitBtn = loginForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Logging in...';
                submitBtn.disabled = true;

                try {
                    const result = await AuthService.login({ email, password });
                    
                    if (result.success) {
                        // Store token and user data
                        StorageService.setToken(result.data.token);
                        StorageService.setUser(result.data.user);
                        
                        alert('Login successful!');
                        // Redirect or update UI
                        window.location.href = 'webpages/dashboard.html'; // You can create this later
                    } else {
                        alert('Login failed: ' + result.message);
                    }
                } catch (error) {
                    alert('Login error: ' + error.message);
                } finally {
                    // Restore button state
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                }
            }
        });
    }

    // Enhanced Contact Form Handler
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', async function(event) {
            event.preventDefault();

            const fullName = document.getElementById('fullName').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;

            // Clear previous errors and success message
            document.querySelectorAll('.con-error').forEach(error => error.textContent = '');
            document.getElementById('successMessage').textContent = '';

            let valid = true;

            // Validate Full Name
            if (fullName.trim() === '' || fullName.length < 2) {
                document.getElementById('fullNameError').textContent = 'Full Name must be at least 2 characters long.';
                valid = false;
            }

            // Validate Email
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                document.getElementById('emailError').textContent = 'Please enter a valid email address.';
                valid = false;
            }

            // Validate Message
            if (message.trim() === '' || message.length < 10) {
                document.getElementById('messageError').textContent = 'Message must be at least 10 characters long.';
                valid = false;
            }

            if (valid) {
                const submitBtn = contactForm.querySelector('input[type="submit"]');
                const originalValue = submitBtn.value;
                submitBtn.value = 'Sending...';
                submitBtn.disabled = true;

                try {
                    const result = await ContactService.sendMessage({
                        full_name: fullName,
                        email: email,
                        subject: 'Website Inquiry', // You can add a subject field later
                        message: message
                    });

                    if (result.success) {
                        document.getElementById('successMessage').textContent = result.message;
                        contactForm.reset();
                    } else {
                        document.getElementById('successMessage').textContent = 'Error: ' + result.message;
                        document.getElementById('successMessage').style.color = 'red';
                    }
                } catch (error) {
                    document.getElementById('successMessage').textContent = 'Network error occurred';
                    document.getElementById('successMessage').style.color = 'red';
                } finally {
                    submitBtn.value = originalValue;
                    submitBtn.disabled = false;
                }
            }
        });
    }

    // Load Courses from Backend (Optional Enhancement)
    const courseContainer = document.querySelector('.course-slider');
    if (courseContainer) {
        loadCoursesFromBackend();
    }
});

// Function to load courses from backend
async function loadCoursesFromBackend() {
    try {
        const result = await CourseService.getAllCourses();
        
        if (result.success) {
            // You can dynamically update the course slider with real data
            console.log('Courses loaded:', result.data.courses);
            // Optional: Update your course cards with real data
            updateCourseCards(result.data.courses);
        }
    } catch (error) {
        console.error('Failed to load courses:', error);
    }
}

function updateCourseCards(courses) {
    // Optional: Update your existing course cards with real data from backend
    const courseCards = document.querySelectorAll('.course-card');
    courses.forEach((course, index) => {
        if (courseCards[index]) {
            // Update course title, description, etc.
            const titleElement = courseCards[index].querySelector('.name');
            const descElement = courseCards[index].querySelector('.namee');
            
            if (titleElement) titleElement.textContent = course.title;
            if (descElement) descElement.textContent = course.description;
        }
    });
}

// Keep all your existing JavaScript code (FAQs, Gallery, etc.)
// ==================== AI CHATBOT - SIMPLE VERSION ====================
document.addEventListener('DOMContentLoaded', function() {
    // Chatbot elements
    const chatbotWidget = document.getElementById('chatbotWidget');
    const chatbotToggle = document.getElementById('chatbotToggle');
    const closeChatbot = document.getElementById('closeChatbot');
    const chatbotMessages = document.getElementById('chatbotMessages');
    const chatbotInput = document.getElementById('chatbotInput');
    const sendMessage = document.getElementById('sendMessage');
    
    let isChatbotOpen = false;
    let isTyping = false;

    // Open/close chatbot
    chatbotToggle.addEventListener('click', function() {
        isChatbotOpen = !isChatbotOpen;
        chatbotWidget.style.display = isChatbotOpen ? 'flex' : 'none';
        
        if (isChatbotOpen) {
            chatbotInput.focus();
        }
    });

    closeChatbot.addEventListener('click', function() {
        isChatbotOpen = false;
        chatbotWidget.style.display = 'none';
    });

    // Send message function
    function sendUserMessage() {
        const message = chatbotInput.value.trim();
        if (!message || isTyping) return;

        // Add user message to chat
        addMessage(message, 'user');
        chatbotInput.value = '';

        // Show typing indicator
        showTypingIndicator();

        // Get bot response
        getBotResponse(message)
            .then(response => {
                removeTypingIndicator();
                addMessage(response, 'bot');
            })
            .catch(error => {
                removeTypingIndicator();
                addMessage("Sorry, I'm having trouble responding right now. Please try again later.", 'bot');
                console.error('Chatbot error:', error);
            });
    }

    // Send message on button click
    sendMessage.addEventListener('click', sendUserMessage);

    // Send message on Enter key
    chatbotInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendUserMessage();
        }
    });

    // Add message to chat
    function addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = sender + '-message';
        messageDiv.textContent = text;
        chatbotMessages.appendChild(messageDiv);
        
        // Scroll to bottom
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }

    // Show typing indicator
    function showTypingIndicator() {
        isTyping = true;
        const typingDiv = document.createElement('div');
        typingDiv.className = 'bot-message typing-indicator';
        typingDiv.id = 'typingIndicator';
        typingDiv.textContent = 'Typing...';
        chatbotMessages.appendChild(typingDiv);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }

    // Remove typing indicator
    function removeTypingIndicator() {
        isTyping = false;
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    // Get response from backend
    async function getBotResponse(message) {
        try {
            const response = await fetch('../backend/api/chatbot.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    message: message,
                    context: 'general'
                })
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            
            if (data.success) {
                return data.data.response;
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            throw error;
        }
    }

    console.log('🤖 E-Rozgaar Chatbot initialized!');
});
// Temporary test - add this at the bottom of your index.js
setTimeout(function() {
    const elements = {
        chatbotWidget: document.getElementById('chatbotWidget'),
        chatbotToggle: document.getElementById('chatbotToggle'),
        chatbotMessages: document.getElementById('chatbotMessages'),
        chatbotInput: document.getElementById('chatbotInput'),
        sendMessage: document.getElementById('sendMessage'),
        closeChatbot: document.getElementById('closeChatbot')
    };
    
    console.log('🔍 Chatbot Elements Check:');
    for (const [name, element] of Object.entries(elements)) {
        if (element) {
            console.log('✅ ' + name + ' - FOUND');
        } else {
            console.log('❌ ' + name + ' - NOT FOUND');
        }
    }
}, 1000);