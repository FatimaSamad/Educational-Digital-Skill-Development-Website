<?php
// Database Configuration - UPDATE THESE!
define('DB_HOST', 'localhost');
define('DB_USER', 'root');      // Usually 'root' for XAMPP/WAMP
define('DB_PASS', '');          // Usually empty for XAMPP/WAMP
define('DB_NAME', 'e_rozgaar');

// Application Configuration
define('BASE_URL', 'http://localhost/e-rozgaar/backend');
define('SITE_NAME', 'E-Rozgaar');
define('JWT_SECRET', 'e_rozgaar_secret_key_2024_change_this');
define('JWT_ALGORITHM', 'HS256');

// File Upload Configuration
define('MAX_FILE_SIZE', 5 * 1024 * 1024);
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif']);

// CORS Headers
header("Access-Control-Allow-Origin: *"); // Change to your frontend URL later
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}
?>