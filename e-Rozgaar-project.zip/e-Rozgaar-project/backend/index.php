<?php
require_once 'config/constants.php';

// Simple routing
$request = $_SERVER['REQUEST_URI'];
$method = $_SERVER['REQUEST_METHOD'];

// Remove query string
$path = parse_url($request, PHP_URL_PATH);
$path = str_replace('/backend', '', $path); // Adjust based on your folder structure

// Route requests
switch (true) {
    case preg_match('/^\/api\/auth/', $path):
        require 'api/auth.php';
        break;
    case preg_match('/^\/api\/courses/', $path):
        require 'api/courses.php';
        break;
    case preg_match('/^\/api\/contact/', $path):
        require 'api/contact.php';
        break;
    default:
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'API endpoint not found',
            'path' => $path
        ]);
        break;
}
?>