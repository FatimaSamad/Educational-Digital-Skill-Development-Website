<?php
require_once '../config/constants.php';
require_once '../includes/Response.php';
require_once '../includes/Validation.php';
require_once '../includes/JWT.php';
require_once '../models/User.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

class AuthController {
    private $user;

    public function __construct() {
        $this->user = new User();
    }

    public function register() {
        try {
            $data = json_decode(file_get_contents("php://input"), true);
            
            // Validation
            $requiredFields = ['full_name', 'email', 'password', 'phone', 'address', 'education'];
            $validationErrors = Validation::validateRequired(array_intersect_key($data, array_flip($requiredFields)));
            
            if (!empty($validationErrors)) {
                Response::error('Validation failed', ['errors' => $validationErrors]);
            }

            if (!Validation::validateEmail($data['email'])) {
                Response::error('Please provide a valid email address');
            }

            if (!Validation::validatePassword($data['password'])) {
                Response::error('Password must be at least 6 characters long');
            }

            if (!Validation::validateName($data['full_name'])) {
                Response::error('Full name must be at least 2 characters long and contain only letters');
            }

            // Check if user already exists
            if ($this->user->findByEmail($data['email'])) {
                Response::error('User already exists with this email');
            }

            // Create user
            $user = new User();
            $user->full_name = Validation::sanitizeInput($data['full_name']);
            $user->email = Validation::sanitizeInput($data['email']);
            $user->password = $data['password']; // Will be hashed in model
            $user->phone = Validation::sanitizeInput($data['phone']);
            $user->address = Validation::sanitizeInput($data['address']);
            $user->education = Validation::sanitizeInput($data['education']);

            $userId = $user->create();

            if ($userId) {
                $token = JWT::encode([
                    'user_id' => $userId,
                    'email' => $user->email,
                    'exp' => time() + (60 * 60 * 24 * 30) // 30 days
                ]);

                Response::success('User registered successfully', [
                    'token' => $token,
                    'user' => [
                        'id' => $userId,
                        'full_name' => $user->full_name,
                        'email' => $user->email,
                        'role' => 'student'
                    ]
                ], 201);
            } else {
                Response::error('Failed to create user');
            }

        } catch (Exception $e) {
            error_log("Registration Error: " . $e->getMessage());
            Response::serverError('Registration failed');
        }
    }

    public function login() {
        try {
            $data = json_decode(file_get_contents("php://input"), true);

            if (!isset($data['email']) || !isset($data['password'])) {
                Response::error('Email and password are required');
            }

            $user = $this->user->findByEmail($data['email']);

            if (!$user || !$this->user->verifyPassword($data['password'], $user->password)) {
                Response::error('Invalid email or password', [], 401);
            }

            $token = JWT::encode([
                'user_id' => $user->id,
                'email' => $user->email,
                'exp' => time() + (60 * 60 * 24 * 30) // 30 days
            ]);

            Response::success('Login successful', [
                'token' => $token,
                'user' => [
                    'id' => $user->id,
                    'full_name' => $user->full_name,
                    'email' => $user->email,
                    'role' => $user->role
                ]
            ]);

        } catch (Exception $e) {
            error_log("Login Error: " . $e->getMessage());
            Response::serverError('Login failed');
        }
    }

    public function getProfile() {
        try {
            $token = $this->getBearerToken();
            $payload = JWT::validateToken($token);

            if (!$payload) {
                Response::unauthorized('Invalid or expired token');
            }

            $user = $this->user->findById($payload['user_id']);

            if (!$user) {
                Response::notFound('User not found');
            }

            Response::success('Profile retrieved successfully', ['user' => $user]);

        } catch (Exception $e) {
            error_log("Get Profile Error: " . $e->getMessage());
            Response::serverError('Failed to retrieve profile');
        }
    }

    private function getBearerToken() {
        $headers = getallheaders();
        if (isset($headers['Authorization'])) {
            $matches = [];
            if (preg_match('/Bearer\s(\S+)/', $headers['Authorization'], $matches)) {
                return $matches[1];
            }
        }
        return null;
    }
}

// Route the request
$auth = new AuthController();
$method = $_SERVER['REQUEST_METHOD'];
$path = isset($_GET['action']) ? $_GET['action'] : '';

switch ($path) {
    case 'register':
        if ($method === 'POST') $auth->register();
        else Response::error('Method not allowed', [], 405);
        break;
    case 'login':
        if ($method === 'POST') $auth->login();
        else Response::error('Method not allowed', [], 405);
        break;
    case 'profile':
        if ($method === 'GET') $auth->getProfile();
        else Response::error('Method not allowed', [], 405);
        break;
    default:
        Response::notFound('Endpoint not found');
        break;
}
?>