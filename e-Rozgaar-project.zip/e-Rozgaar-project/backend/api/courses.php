<?php
require_once '../config/constants.php';
require_once '../includes/Response.php';
require_once '../includes/JWT.php';
require_once '../models/Course.php';
require_once '../models/Enrollment.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

class CourseController {
    private $course;
    private $enrollment;

    public function __construct() {
        $this->course = new Course();
        $this->enrollment = new Enrollment();
    }

    public function getAllCourses() {
        try {
            $courses = $this->course->getAll();
            Response::success('Courses retrieved successfully', ['courses' => $courses]);
        } catch (Exception $e) {
            error_log("Get Courses Error: " . $e->getMessage());
            Response::serverError('Failed to retrieve courses');
        }
    }

    public function getCourse($id) {
        try {
            $course = $this->course->findById($id);
            
            if (!$course) {
                Response::notFound('Course not found');
            }

            Response::success('Course retrieved successfully', ['course' => $course]);
        } catch (Exception $e) {
            error_log("Get Course Error: " . $e->getMessage());
            Response::serverError('Failed to retrieve course');
        }
    }

    public function enrollCourse() {
        try {
            $token = $this->getBearerToken();
            $payload = JWT::validateToken($token);

            if (!$payload) {
                Response::unauthorized('Invalid or expired token');
            }

            $data = json_decode(file_get_contents("php://input"), true);
            
            if (!isset($data['course_id'])) {
                Response::error('Course ID is required');
            }

            $course = $this->course->findById($data['course_id']);
            if (!$course) {
                Response::notFound('Course not found');
            }

            $result = $this->enrollment->enroll($payload['user_id'], $data['course_id']);

            if ($result) {
                Response::success('Successfully enrolled in course');
            } else {
                Response::error('Already enrolled in this course or enrollment failed');
            }

        } catch (Exception $e) {
            error_log("Enrollment Error: " . $e->getMessage());
            Response::serverError('Enrollment failed');
        }
    }

    public function getMyCourses() {
        try {
            $token = $this->getBearerToken();
            $payload = JWT::validateToken($token);

            if (!$payload) {
                Response::unauthorized('Invalid or expired token');
            }

            $enrollments = $this->enrollment->getUserEnrollments($payload['user_id']);
            Response::success('Enrollments retrieved successfully', ['enrollments' => $enrollments]);

        } catch (Exception $e) {
            error_log("Get My Courses Error: " . $e->getMessage());
            Response::serverError('Failed to retrieve enrollments');
        }
    }

    private function getBearerToken() {
        $headers = getallheaders();
        if (isset($headers['Authorization'])) {
            $matches = [];
            if (preg_match('/Bearer\s(\S+)/', $headers['Authorization'], $matches)) {
                return $matches[1];
            }
        }
        return null;
    }
}

// Route the request
$courseController = new CourseController();
$method = $_SERVER['REQUEST_METHOD'];
$path = isset($_GET['action']) ? $_GET['action'] : '';

switch ($path) {
    case '':
        if ($method === 'GET') $courseController->getAllCourses();
        else Response::error('Method not allowed', [], 405);
        break;
    case 'enroll':
        if ($method === 'POST') $courseController->enrollCourse();
        else Response::error('Method not allowed', [], 405);
        break;
    case 'my-courses':
        if ($method === 'GET') $courseController->getMyCourses();
        else Response::error('Method not allowed', [], 405);
        break;
    default:
        // Check if it's a numeric ID
        if (is_numeric($path)) {
            if ($method === 'GET') $courseController->getCourse($path);
            else Response::error('Method not allowed', [], 405);
        } else {
            Response::notFound('Endpoint not found');
        }
        break;
}
?>