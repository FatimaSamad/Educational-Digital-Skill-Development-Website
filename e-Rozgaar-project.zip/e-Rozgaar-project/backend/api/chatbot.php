<?php
require_once '../config/constants.php';
require_once '../includes/Response.php';
require_once '../includes/JWT.php';

header('Content-Type: application/json');

// Handle CORS
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

class ChatbotController {
    private $apiKey;
    
    public function __construct() {
        // You can get API key from environment or use rule-based system
        $this->apiKey = getenv('OPENAI_API_KEY') ?: 'your-openai-api-key-here';
    }
    
    public function handleMessage() {
        try {
            // Get JSON input
            $input = file_get_contents('php://input');
            $data = json_decode($input, true);
            
            if (!$data) {
                Response::error('Invalid JSON data');
            }
            
            if (!isset($data['message']) || empty(trim($data['message']))) {
                Response::error('Message is required');
            }
            
            $userMessage = trim($data['message']);
            $context = $data['context'] ?? 'general';
            
            // Get AI response
            $aiResponse = $this->getAIResponse($userMessage, $context);
            
            Response::success('Response generated successfully', [
                'response' => $aiResponse,
                'context' => $context
            ]);
            
        } catch (Exception $e) {
            error_log("Chatbot Error: " . $e->getMessage());
            Response::serverError('Failed to process your message. Please try again.');
        }
    }
    
    private function getAIResponse($message, $context) {
        // Use rule-based system (FREE) - Remove this if you want to use OpenAI API
        return $this->getRuleBasedResponse($message, $context);
        
        // Uncomment below if you have OpenAI API key (PAID)
        // if ($this->apiKey && $this->apiKey !== 'your-openai-api-key-here') {
        //     return $this->getOpenAIResponse($message, $context);
        // } else {
        //     return $this->getRuleBasedResponse($message, $context);
        // }
    }
    
    private function getRuleBasedResponse($message, $context) {
        $message = strtolower(trim($message));
        
        // Course-related queries
        if (strpos($message, 'course') !== false || strpos($message, 'learn') !== false || strpos($message, 'study') !== false) {
            return $this->handleCourseQuery($message);
        }
        
        // Enrollment queries
        if (strpos($message, 'enroll') !== false || strpos($message, 'join') !== false || strpos($message, 'register') !== false || strpos($message, 'admission') !== false) {
            return "You can enroll in any course by clicking the 'Enroll Now' button on the course card. First, you'll need to create an account if you haven't already. The enrollment process is completely free!";
        }
        
        // Contact queries
        if (strpos($message, 'contact') !== false || strpos($message, 'email') !== false || strpos($message, 'phone') !== false || strpos($message, 'address') !== false) {
            return "You can reach us at:\n📧 Email: hello@lamstan.tech\n📞 Phone: 03445969163\n📍 Address: Lamstan Technology, Skardu\n\nWe're also available on social media!";
        }
        
        // Fee queries
        if (strpos($message, 'fee') !== false || strpos($message, 'cost') !== false || strpos($message, 'price') !== false || strpos($message, 'free') !== false) {
            return "Great news! All E-Rozgaar courses are completely FREE! 🎉 We believe in making digital education accessible to everyone. There are no hidden charges or fees.";
        }
        
        // Duration queries
        if (strpos($message, 'duration') !== false || strpos($message, 'long') !== false || strpos($message, 'week') !== false || strpos($message, 'month') !== false) {
            return "Course durations vary:\n• Web Development: 8 weeks\n• WordPress: 6 weeks\n• Basic IT: 4 weeks\n• C++: 10 weeks\n• Data Science: 12 weeks\n• Digital Marketing: 8 weeks\n• Cyber Security: 10 weeks";
        }
        
        // Greetings
        if (strpos($message, 'hello') !== false || strpos($message, 'hi') !== false || strpos($message, 'hey') !== false) {
            return "Hello! 👋 I'm the E-Rozgaar assistant. I can help you with:\n• Course information\n• Enrollment process\n• Contact details\n• Platform guidance\n\nWhat would you like to know?";
        }
        
        // Thank you responses
        if (strpos($message, 'thank') !== false || strpos($message, 'thanks') !== false) {
            return "You're welcome! 😊 I'm happy to help. If you have any more questions about E-Rozgaar courses or need assistance with enrollment, just let me know!";
        }
        
        // About E-Rozgaar
        if (strpos($message, 'what is e-rozgaar') !== false || strpos($message, 'about') !== false) {
            return "E-Rozgaar is a digital skills training program that empowers youth with in-demand digital skills. We provide free training in various IT fields to help you build a successful career in the digital economy!";
        }
        
        // Default response for unknown queries
        return "I'm here to help you with E-Rozgaar! 🤖 You can ask me about:\n\n📚 Courses and content\n🎯 Enrollment process\n🕐 Course durations\n💼 Career opportunities\n📞 Contact information\n\nWhat specific information are you looking for?";
    }
    
    private function handleCourseQuery($message) {
        if (strpos($message, 'web') !== false || strpos($message, 'development') !== false) {
            return "🌐 **Web Development Course**:\n• Duration: 8 weeks\n• Level: Beginner\n• Learn: HTML, CSS, JavaScript\n• Build responsive websites\n• Perfect for starting a freelancing career!";
        }
        
        if (strpos($message, 'wordpress') !== false || strpos($message, 'wp') !== false) {
            return "🚀 **WordPress Course**:\n• Duration: 6 weeks\n• Level: Beginner\n• Learn: Website creation & management\n• E-commerce sites\n• Blog management\n• No coding experience needed!";
        }
        
        if (strpos($message, 'data') !== false || strpos($message, 'science') !== false) {
            return "📊 **Data Science Course**:\n• Duration: 12 weeks\n• Level: Intermediate\n• Learn: Python, Statistics, ML\n• Data analysis & visualization\n• Real-world data projects";
        }
        
        if (strpos($message, 'digital') !== false || strpos($message, 'marketing') !== false) {
            return "📱 **Digital Marketing Course**:\n• Duration: 8 weeks\n• Level: Beginner\n• Learn: SEO, Social Media, Ads\n• Brand growth strategies\n• Content marketing";
        }
        
        if (strpos($message, 'cyber') !== false || strpos($message, 'security') !== false) {
            return "🔒 **Cyber Security Course**:\n• Duration: 10 weeks\n• Level: Intermediate\n• Learn: Security fundamentals\n• Threat protection\n• Data safeguarding\n• Network security";
        }
        
        if (strpos($message, 'c++') !== false || strpos($message, 'cpp') !== false) {
            return "💻 **C++ Programming Course**:\n• Duration: 10 weeks\n• Level: Beginner\n• Learn: Programming fundamentals\n• Object-oriented programming\n• Problem-solving skills";
        }
        
        if (strpos($message, 'basic') !== false || strpos($message, 'it') !== false) {
            return "🖥️ **Basic IT Course**:\n• Duration: 4 weeks\n• Level: Beginner\n• Learn: Computer fundamentals\n• Essential software skills\n• IT basics for everyone";
        }
        
        // General course information
        return "We offer these exciting courses:\n\n🌐 Web Development (8 weeks)\n🚀 WordPress (6 weeks)\n🖥️ Basic IT (4 weeks)\n💻 C++ Programming (10 weeks)\n📊 Data Science (12 weeks)\n📱 Digital Marketing (8 weeks)\n🔒 Cyber Security (10 weeks)\n\nWhich course interests you the most?";
    }
    
    private function getOpenAIResponse($message, $context) {
        // Only use this if you have a paid OpenAI API key
        $prompt = $this->buildPrompt($message, $context);
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.openai.com/v1/chat/completions');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => $prompt
                ],
                [
                    'role' => 'user',
                    'content' => $message
                ]
            ],
            'max_tokens' => 200,
            'temperature' => 0.7
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->apiKey
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            error_log("OpenAI API Error: " . $response);
            return $this->getRuleBasedResponse($message, $context);
        }
        
        $data = json_decode($response, true);
        
        if (isset($data['choices'][0]['message']['content'])) {
            return trim($data['choices'][0]['message']['content']);
        }
        
        return $this->getRuleBasedResponse($message, $context);
    }
    
    private function buildPrompt($message, $context) {
        return "You are an AI assistant for E-Rozgaar, a digital skills training platform in Pakistan. 

IMPORTANT INFORMATION ABOUT E-ROZGAAR:
- All courses are COMPLETELY FREE
- Platform provides digital skills training to youth
- Contact email: hello@lamstan.tech
- Phone: 03445969163
- Address: Lamstan Technology, Skardu

AVAILABLE COURSES:
1. Web Development (8 weeks) - HTML, CSS, JavaScript
2. WordPress (6 weeks) - Website creation and management
3. Basic IT (4 weeks) - Computer fundamentals
4. C++ Programming (10 weeks) - Programming basics
5. Data Science (12 weeks) - Python, statistics, machine learning
6. Digital Marketing (8 weeks) - SEO, social media, online advertising
7. Cyber Security (10 weeks) - Security fundamentals, threat protection

YOUR ROLE:
- Be friendly, helpful, and encouraging
- Provide accurate information about E-Rozgaar
- Keep responses concise but informative
- Use emojis occasionally to make it engaging
- If unsure, suggest contacting the support team
- Always mention that courses are free

Current context: $context

Respond to the user's query appropriately:";
    }
}

// Handle the request
$chatbot = new ChatbotController();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $chatbot->handleMessage();
} else {
    Response::error('Method not allowed. Please use POST.', [], 405);
}
?>