<?php
require_once '../config/constants.php';
require_once '../includes/Response.php';
require_once '../includes/Validation.php';
require_once '../models/Contact.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

class ContactController {
    private $contact;

    public function __construct() {
        $this->contact = new Contact();
    }

    public function createMessage() {
        try {
            $data = json_decode(file_get_contents("php://input"), true);
            
            // Validation
            $requiredFields = ['full_name', 'email', 'subject', 'message'];
            $validationErrors = Validation::validateRequired(array_intersect_key($data, array_flip($requiredFields)));
            
            if (!empty($validationErrors)) {
                Response::error('Validation failed', ['errors' => $validationErrors]);
            }

            if (!Validation::validateEmail($data['email'])) {
                Response::error('Please provide a valid email address');
            }

            if (!Validation::validateName($data['full_name'])) {
                Response::error('Full name must be at least 2 characters long');
            }

            if (strlen($data['message']) < 10) {
                Response::error('Message must be at least 10 characters long');
            }

            // Sanitize data
            $sanitizedData = [
                'full_name' => Validation::sanitizeInput($data['full_name']),
                'email' => Validation::sanitizeInput($data['email']),
                'subject' => Validation::sanitizeInput($data['subject']),
                'message' => Validation::sanitizeInput($data['message'])
            ];

            $messageId = $this->contact->create($sanitizedData);

            if ($messageId) {
                // Send email notification (you can implement this)
                $this->sendEmailNotification($sanitizedData);
                
                Response::success('Your message has been sent successfully!', [], 201);
            } else {
                Response::error('Failed to send message');
            }

        } catch (Exception $e) {
            error_log("Contact Form Error: " . $e->getMessage());
            Response::serverError('Failed to send message');
        }
    }

    private function sendEmailNotification($data) {
        // Implement email sending using PHPMailer or mail() function
        $to = ADMIN_EMAIL;
        $subject = "New Contact Form: " . $data['subject'];
        $message = "
            <h3>New Contact Form Submission</h3>
            <p><strong>Name:</strong> {$data['full_name']}</p>
            <p><strong>Email:</strong> {$data['email']}</p>
            <p><strong>Subject:</strong> {$data['subject']}</p>
            <p><strong>Message:</strong></p>
            <p>{$data['message']}</p>
        ";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: {$data['email']}" . "\r\n";

        @mail($to, $subject, $message, $headers);
    }
}

// Route the request
$contactController = new ContactController();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $contactController->createMessage();
} else {
    Response::error('Method not allowed', [], 405);
}
?>