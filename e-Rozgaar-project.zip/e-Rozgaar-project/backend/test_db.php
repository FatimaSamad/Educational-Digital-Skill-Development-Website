<?php
require_once 'config/constants.php';
require_once 'config/database.php';

header('Content-Type: application/json');

try {
    $database = new Database();
    
    // Test connection by querying courses
    $database->query("SELECT COUNT(*) as course_count FROM courses");
    $result = $database->single();
    
    echo json_encode([
        'success' => true,
        'message' => 'Database connection successful!',
        'data' => [
            'courses_count' => $result->course_count,
            'database' => DB_NAME,
            'host' => DB_HOST
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed',
        'error' => $e->getMessage()
    ]);
}
?>