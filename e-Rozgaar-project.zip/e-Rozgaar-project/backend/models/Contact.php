<?php
require_once 'config/database.php';

class Contact {
    private $db;
    private $table = 'contact_messages';

    public $id;
    public $full_name;
    public $email;
    public $subject;
    public $message;
    public $status;
    public $created_at;

    public function __construct() {
        $this->db = new Database();
    }

    public function create($data) {
        $this->db->query("INSERT INTO {$this->table} (full_name, email, subject, message) 
                         VALUES (:full_name, :email, :subject, :message)");
        
        $this->db->bind(':full_name', $data['full_name']);
        $this->db->bind(':email', $data['email']);
        $this->db->bind(':subject', $data['subject']);
        $this->db->bind(':message', $data['message']);

        return $this->db->execute() ? $this->db->lastInsertId() : false;
    }

    public function getAll() {
        $this->db->query("SELECT * FROM {$this->table} ORDER BY created_at DESC");
        return $this->db->resultSet();
    }

    public function markAsReplied($id) {
        $this->db->query("UPDATE {$this->table} SET status = 'replied' WHERE id = :id");
        $this->db->bind(':id', $id);
        return $this->db->execute();
    }

    public function getUnreadCount() {
        $this->db->query("SELECT COUNT(*) as count FROM {$this->table} WHERE status = 'new'");
        $result = $this->db->single();
        return $result ? $result->count : 0;
    }
}
?>