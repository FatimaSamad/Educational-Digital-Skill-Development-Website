<?php
require_once 'config/database.php';

class User {
    private $db;
    private $table = 'users';

    public $id;
    public $full_name;
    public $email;
    public $password;
    public $phone;
    public $address;
    public $education;
    public $role;
    public $is_verified;
    public $created_at;

    public function __construct() {
        $this->db = new Database();
    }

    public function create() {
        try {
            $this->db->query("INSERT INTO {$this->table} 
                (full_name, email, password, phone, address, education) 
                VALUES (:full_name, :email, :password, :phone, :address, :education)");
            
            $this->db->bind(':full_name', $this->full_name);
            $this->db->bind(':email', $this->email);
            $this->db->bind(':password', password_hash($this->password, PASSWORD_DEFAULT));
            $this->db->bind(':phone', $this->phone);
            $this->db->bind(':address', $this->address);
            $this->db->bind(':education', $this->education);

            if ($this->db->execute()) {
                return $this->db->lastInsertId();
            }
            return false;
        } catch (PDOException $e) {
            error_log("User Create Error: " . $e->getMessage());
            return false;
        }
    }

    public function findByEmail($email) {
        $this->db->query("SELECT * FROM {$this->table} WHERE email = :email");
        $this->db->bind(':email', $email);
        return $this->db->single();
    }

    public function findById($id) {
        $this->db->query("SELECT id, full_name, email, phone, address, education, role, created_at 
                         FROM {$this->table} WHERE id = :id");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    public function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }

    public function updateProfile($data) {
        $query = "UPDATE {$this->table} SET full_name = :full_name, phone = :phone, 
                 address = :address, education = :education WHERE id = :id";
        
        $this->db->query($query);
        $this->db->bind(':full_name', $data['full_name']);
        $this->db->bind(':phone', $data['phone']);
        $this->db->bind(':address', $data['address']);
        $this->db->bind(':education', $data['education']);
        $this->db->bind(':id', $data['id']);

        return $this->db->execute();
    }
}
?>