<?php
require_once 'config/database.php';

class Enrollment {
    private $db;
    private $table = 'enrollments';

    public $id;
    public $user_id;
    public $course_id;
    public $progress;
    public $completed;
    public $enrolled_at;

    public function __construct() {
        $this->db = new Database();
    }

    public function enroll($user_id, $course_id) {
        // Check if already enrolled
        if ($this->isEnrolled($user_id, $course_id)) {
            return false;
        }

        $this->db->query("INSERT INTO {$this->table} (user_id, course_id) VALUES (:user_id, :course_id)");
        $this->db->bind(':user_id', $user_id);
        $this->db->bind(':course_id', $course_id);

        return $this->db->execute();
    }

    public function isEnrolled($user_id, $course_id) {
        $this->db->query("SELECT id FROM {$this->table} WHERE user_id = :user_id AND course_id = :course_id");
        $this->db->bind(':user_id', $user_id);
        $this->db->bind(':course_id', $course_id);
        return $this->db->single() ? true : false;
    }

    public function getUserEnrollments($user_id) {
        $this->db->query("SELECT e.*, c.title, c.description, c.category, c.instructor, c.duration, c.image 
                         FROM {$this->table} e 
                         JOIN courses c ON e.course_id = c.id 
                         WHERE e.user_id = :user_id 
                         ORDER BY e.enrolled_at DESC");
        $this->db->bind(':user_id', $user_id);
        return $this->db->resultSet();
    }

    public function updateProgress($enrollment_id, $progress) {
        $this->db->query("UPDATE {$this->table} SET progress = :progress WHERE id = :id");
        $this->db->bind(':progress', $progress);
        $this->db->bind(':id', $enrollment_id);
        return $this->db->execute();
    }
}
?>