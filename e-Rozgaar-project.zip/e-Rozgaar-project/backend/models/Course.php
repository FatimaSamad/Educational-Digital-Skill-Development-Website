<?php
require_once 'config/database.php';

class Course {
    private $db;
    private $table = 'courses';

    public $id;
    public $title;
    public $description;
    public $category;
    public $instructor;
    public $duration;
    public $level;
    public $price;
    public $image;
    public $is_active;
    public $created_at;

    public function __construct() {
        $this->db = new Database();
    }

    public function getAll() {
        $this->db->query("SELECT * FROM {$this->table} WHERE is_active = 1 ORDER BY created_at DESC");
        return $this->db->resultSet();
    }

    public function findById($id) {
        $this->db->query("SELECT * FROM {$this->table} WHERE id = :id AND is_active = 1");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    public function getByCategory($category) {
        $this->db->query("SELECT * FROM {$this->table} WHERE category = :category AND is_active = 1");
        $this->db->bind(':category', $category);
        return $this->db->resultSet();
    }

    public function create($data) {
        $this->db->query("INSERT INTO {$this->table} 
            (title, description, category, instructor, duration, level, price, image) 
            VALUES (:title, :description, :category, :instructor, :duration, :level, :price, :image)");
        
        foreach ($data as $key => $value) {
            $this->db->bind(':' . $key, $value);
        }

        return $this->db->execute() ? $this->db->lastInsertId() : false;
    }

    public function getPopularCourses($limit = 6) {
        $this->db->query("SELECT c.*, COUNT(e.id) as enrollment_count 
                         FROM {$this->table} c 
                         LEFT JOIN enrollments e ON c.id = e.course_id 
                         WHERE c.is_active = 1 
                         GROUP BY c.id 
                         ORDER BY enrollment_count DESC 
                         LIMIT :limit");
        $this->db->bind(':limit', $limit);
        return $this->db->resultSet();
    }
}
?>