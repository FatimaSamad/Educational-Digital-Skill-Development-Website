<?php
require_once 'config/constants.php';
require_once 'includes/Response.php';

// Test the chatbot API
$testMessages = [
    "Hello",
    "What courses do you offer?",
    "Tell me about web development course",
    "How much does it cost?",
    "How can I enroll?",
    "What is your contact information?"
];

foreach ($testMessages as $message) {
    echo "Testing: '$message'\n";
    
    $data = ['message' => $message];
    $url = 'http://localhost/your-project-folder/backend/api/chatbot.php';
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    
    if ($result['success']) {
        echo "✅ Response: " . $result['data']['response'] . "\n\n";
    } else {
        echo "❌ Error: " . $result['message'] . "\n\n";
    }
    
    echo "------------------------\n";
}
?>