<?php
class Response {
    public static function send($success, $message = '', $data = [], $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        
        $response = [
            'success' => $success,
            'message' => $message,
            'data' => $data,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        echo json_encode($response);
        exit;
    }

    public static function success($message = 'Success', $data = [], $statusCode = 200) {
        self::send(true, $message, $data, $statusCode);
    }

    public static function error($message = 'Error', $data = [], $statusCode = 400) {
        self::send(false, $message, $data, $statusCode);
    }

    public static function serverError($message = 'Internal Server Error') {
        self::send(false, $message, [], 500);
    }

    public static function notFound($message = 'Resource Not Found') {
        self::send(false, $message, [], 404);
    }

    public static function unauthorized($message = 'Unauthorized Access') {
        self::send(false, $message, [], 401);
    }
}
?>