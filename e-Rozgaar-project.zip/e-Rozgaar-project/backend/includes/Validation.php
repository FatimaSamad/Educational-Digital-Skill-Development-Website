<?php
class Validation {
    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function validatePassword($password) {
        return strlen($password) >= 6;
    }

    public static function validateName($name) {
        return strlen(trim($name)) >= 2 && preg_match('/^[a-zA-Z\s]+$/', $name);
    }

    public static function validatePhone($phone) {
        return preg_match('/^[0-9+\-\s()]{10,15}$/', $phone);
    }

    public static function sanitizeInput($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    public static function validateRequired($fields) {
        $errors = [];
        foreach ($fields as $field => $value) {
            if (empty(trim($value))) {
                $errors[] = ucfirst($field) . " is required";
            }
        }
        return $errors;
    }
}
?>